package com.cran.util;

public class Cw {
	public static void w(String s) {
		System.out.print(s);
	}
	public static void w(String s,int a) {
		for(int i=0; i<a;i++) {
		System.out.print(s);
		}
	}
	public static void wn(String s) {
		System.out.println(s);
	}
	public static void wn() {
		System.out.println();
	}
}